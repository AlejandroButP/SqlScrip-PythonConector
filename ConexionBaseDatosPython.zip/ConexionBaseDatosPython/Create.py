import mysql.connector
mydb= mysql.connector.connect(user='root', password='12345',
                              host='localhost', database='canchas',
                              auth_plugin='mysql_native_password')
Cursor = mydb.cursor()

def CrearUsuario(nombre,numero_documento,correro_electronico,numero_celular,contraseña):
    
    Cursor.callproc("CrearUsuario",(nombre,numero_documento,correro_electronico,numero_celular,contraseña))
    

    for result in Cursor.stored_results():
        print(result.fetchall())

    mydb.commit()

#frontend
#p1 = input("Ingrese el nombre de el usuario ")
#p2 = input("Ingrese el numero de documento ")
#p3= input("Ingrese el correo electronco ")
#p4= input("Ingrese el numero de celular ")
#p5= input("Ingrese su contraseña ")
#CrearUsuario(p1,p2,p3,p4,p5)
