import mysql.connector
mydb= mysql.connector.connect(user='root', password='12345',
                              host='localhost', database='canchas',
                              auth_plugin='mysql_native_password')
Cursor = mydb.cursor()

def CanchasUs(FechaInicio,FechaFin):
    
    Cursor.callproc("CanchasMasUsadas",(FechaInicio,FechaFin))
    

    for result in Cursor.stored_results():
        print(result.fetchall())

    mydb.commit()
#p1=input("Ingrese fecha inico")
#p2=input("Ingrese fecha fin")
#CanchasMasUsadas(p1,p2)