import Create as Cre
import Read as Red
import Update as Upd
import Delete as Del
import CanchasUsadas
import ClienteFrecuente 
import ConsultaReserva

opc='0'
while not(opc=='9'):
    print("BASES DE DATOS ALQUILES DE CANCHAS")
    print("1. Ingrese un nuevo Cliente")
    print("2. Busque un cliente")
    print("3. Actualize un cliente ")
    print("4. Borrar cliente")
    print("5. Canchas mas usadas en un rango de tiempo ")
    print("6. Usuarios que mas alquilan canchas en un rango de tiempo ")
    print("7. Consultar el historial de reservas por cliente y fecha")
    print("9. Salir")
    opc=input("Ingrese la opcion deseada ")

    if (opc=='1'):
        p1 = input("Ingrese el nombre de el usuario ")
        p2 = input("Ingrese el numero de documento ")
        p3= input("Ingrese el correo electronico ")
        p4= input("Ingrese el numero de celular ")
        p5= input("Ingrese su contraseña ")
        Cre.CrearUsuario(p1,p2,p3,p4,p5)
        print("Opcion 1")
    elif (opc=='2'):
        p1=input("Ingrese el Id cliente a buscar ")
        Red.LeerUsuario(p1)
        print("Opcion 2")
    elif (opc=='3'):
        p1 = input("Ingrese el Id del usuario a actualizar ")
        p2 = input("Ingrese el nombre de el usuario ")
        p3 = input("Ingrese el numero de documento ")
        p4 = input("Ingrese el correo electronco ")
        p5 = input("Ingrese el numero de celular ")
        p6 = input("Ingrese su contraseña ")
        Upd.ActualizarUsuario(p1,p2,p3,p4,p5,p6)
        print("Opcion 3")
    elif (opc=='4'):
        p1=input("Ingrese el ID del cliente a eliminar ")
        Del.EliminarUsuario(p1)
        print("Opcion 4")
    elif (opc=='5'):
        print("Ingrese las fechas de la forma AAAA-MM-DD")
        p1=input("Ingrese la fecha de incio ")
        p2=input("Ingrese la fecha final ")
        CanchasUsadas.CanchasUs(p1,p2)
    elif(opc=='6'):
        print("Ingrese las fechas de la forma AAAA-MM-DD")
        p1=input("Ingrese la fecha de incio ")
        p2=input("Ingrese la fecha final ")
        ClienteFrecuente.ClienteFr(p1,p2)
    elif(opc=='7'):
        print("Ingrese las fechas de la forma AAAA-MM-DD")
        p1=input("Ingrese codigo cliente ")
        p2=input("Ingrese la fecha reserva ")
        ConsultaReserva.ConsultaRs(p1,p2)
    elif(opc==9):
        print("Fin Programa")








