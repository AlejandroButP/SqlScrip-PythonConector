import mysql.connector
mydb= mysql.connector.connect(user='root', password='12345',
                              host='localhost', database='canchas',
                              auth_plugin='mysql_native_password')
Cursor = mydb.cursor()

def EliminarUsuario(Codigo):
    
    Cursor.callproc("BorrarUsuario",(Codigo,))
    

    for result in Cursor.stored_results():
        print(result.fetchall())

    mydb.commit()

#frontend
#p1 = input("Ingrese el Id del usuario que quiere eliminar")
#EliminarUsuario(p1)