import mysql.connector
mydb= mysql.connector.connect(user='root', password='12345',
                              host='localhost', database='canchas',
                              auth_plugin='mysql_native_password')
Cursor = mydb.cursor()

def ActualizarUsuario(Codigo,nombre,numero_documento,correro_electronico,numero_celular,contraseña):
    
    Cursor.callproc("ActualizarUsuario",(Codigo,nombre,numero_documento,correro_electronico,numero_celular,contraseña))
    

    for result in Cursor.stored_results():
        print(result.fetchall())

    mydb.commit()

#frontend
#p1 = input("Ingrese el Id del usuario a actualizar ")
#p2 = input("Ingrese el nombre de el usuario ")
#p3 = input("Ingrese el numero de documento ")
#p4 = input("Ingrese el correo electronco ")
#p5 = input("Ingrese el numero de celular ")
#p6 = input("Ingrese su contraseña ")
#ActualizarUsuario(p6,p1,p2,p3,p4,p5)