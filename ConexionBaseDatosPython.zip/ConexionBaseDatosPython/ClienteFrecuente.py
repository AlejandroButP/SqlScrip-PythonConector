import mysql.connector
mydb= mysql.connector.connect(user='root', password='12345',
                              host='localhost', database='canchas',
                              auth_plugin='mysql_native_password')
Cursor = mydb.cursor()

def ClienteFr(FechaInicio,FechaFin):
    
    Cursor.callproc("ClientesFrecuentes",(FechaInicio,FechaFin))
    

    for result in Cursor.stored_results():
        print(result.fetchall())

    mydb.commit()
